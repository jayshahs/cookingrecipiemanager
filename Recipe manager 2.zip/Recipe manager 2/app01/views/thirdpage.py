from django.shortcuts import render


def page1(request):
    # info = request.session.get("info")
    # if not info:
    #     return redirect('/login/')
    return render(request, 'thirdpage1.html')


def page2(request):
    return render(request, 'thirdpage2.html')


def page3(request):
    return render(request, 'thirdpage3.html')


def page4(request):
    return render(request, 'thirdpage4.html')


def page5(request):
    return render(request, 'thirdpage5.html')


def page6(request):
    return render(request, 'thirdpage6.html')


def page7(request):
    return render(request, 'thirdpage7.html')


def page8(request):
    return render(request, 'thirdpage8.html')


def page9(request):
    return render(request, 'thirdpage9.html')


def page10(request):
    return render(request, 'thirdpage10.html')


def page11(request):
    return render(request, 'thirdpage11.html')


def page12(request):
    return render(request, 'thirdpage12.html')


def page13(request):
    return render(request, 'thirdpage13.html')


def page14(request):
    return render(request, 'thirdpage14.html')


def page15(request):
    return render(request, 'thirdpage15.html')


def page16(request):
    return render(request, 'thirdpage16.html')


def page17(request):
    return render(request, 'thirdpage17.html')


def page18(request):
    return render(request, 'thirdpage18.html')


def page19(request):
    return render(request, 'thirdpage19.html')


def page20(request):
    return render(request, 'thirdpage20.html')

def page21(request):
    return render(request, 'thirdpage21.html')
def page22(request):
    return render(request, 'thirdpage22.html')
def page23(request):
    return render(request, 'thirdpage23.html')
def page24(request):
    return render(request, 'thirdpage24.html')
